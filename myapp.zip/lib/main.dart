import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  double starting = 5000;
  double current = 5000;
  int wins = 0;
  int losses = 0;
  int step = 0;

  double nextStake = 96742;
  double expectedReturn = 290225;

  Widget box(String title, String value, Color valueColor) {
    return Expanded(
      child: Container(
        margin: EdgeInsets.all(6),
        padding: EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          children: [
            Text(title, style: TextStyle(color: Colors.white70, fontSize: 12)),
            SizedBox(height: 5),
            Text(value,
                style: TextStyle(
                    color: valueColor,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  void win() {
    setState(() {
      wins++;
      step++;
      current += expectedReturn;
      nextStake = nextStake / 2;
      expectedReturn = nextStake * 3;
    });
  }

  void loss() {
    setState(() {
      losses++;
      step++;
      current -= nextStake;
      nextStake = nextStake * 2;
      expectedReturn = nextStake * 3;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF1A002B),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text("Money Management"),
        actions: [
          Icon(Icons.tune),
          SizedBox(width: 10),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
          children: [
            Row(
              children: [
                box("STARTING", "৳${starting.toStringAsFixed(0)}",
                    Colors.white),
                box("CURRENT", "৳${current.toStringAsFixed(0)}", Colors.green),
              ],
            ),
            Row(
              children: [
                box("STEP", "$step / 30", Colors.white),
                box("TARGET", "৳5542436", Colors.cyanAccent),
              ],
            ),
            Row(
              children: [
                box("WINS", "$wins", Colors.green),
                box("LOSSES", "$losses", Colors.red),
                box("NEXT STAKE", "৳${nextStake.toStringAsFixed(0)}",
                    Colors.pinkAccent),
              ],
            ),
            SizedBox(height: 15),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(15),
              ),
              child: Column(
                children: [
                  Text("EXPECTED RETURN (IF WIN)",
                      style: TextStyle(color: Colors.white70)),
                  SizedBox(height: 5),
                  Text("+৳${expectedReturn.toStringAsFixed(0)}",
                      style: TextStyle(
                          color: Colors.greenAccent,
                          fontSize: 20,
                          fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: win,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      padding: EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30)),
                    ),
                    child: Text("WIN"),
                  ),
                ),
                SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: loss,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      padding: EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30)),
                    ),
                    child: Text("LOSS"),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
