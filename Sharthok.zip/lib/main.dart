importimportimportimportimportimportimportimport 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  double starting = 5000;
  double current = 5000;
  int step = 0;
  int totalStep = 30;
  int wins = 0;
  int losses = 0;

  double nextStake = 96.74;
  double expectedReturn = 290.226;

  void onWin() {
    setState(() {
      wins++;
      step++;
      current += expectedReturn;
    });
  }

  void onLoss() {
    setState(() {
      losses++;
      step++;
      current -= nextStake;
    });
  }

  void reset() {
    setState(() {
      current = starting;
      wins = 0;
      losses = 0;
      step = 0;
    });
  }

  Widget box(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        children: [
          Text(title, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 5),
          Text(value,
              style: TextStyle(
                  color: color, fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double progress = step / totalStep;

    return Scaffold(
      backgroundColor: const Color(0xFF1A002B),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            children: [
              const Text("Money Management",
                  style: TextStyle(color: Colors.white, fontSize: 20)),
              const SizedBox(height: 15),
              GridView.count(
                shrinkWrap: true,
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                children: [
                  box("STARTING", "৳${starting.toStringAsFixed(0)}",
                      Colors.white),
                  box("CURRENT", "৳${current.toStringAsFixed(0)}",
                      Colors.green),
                  box("STEP", "$step / $totalStep", Colors.white),
                  box("TARGET", "৳5542436", Colors.cyan),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: box("WINS", "$wins", Colors.green)),
                  const SizedBox(width: 10),
                  Expanded(child: box("LOSSES", "$losses", Colors.red)),
                  const SizedBox(width: 10),
                  Expanded(
                      child: box("NEXT STAKE",
                          "৳${nextStake.toStringAsFixed(2)}", Colors.pink)),
                ],
              ),
              const SizedBox(height: 15),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(15),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Column(
                  children: [
                    const Text("EXPECTED RETURN (IF WIN)",
                        style: TextStyle(color: Colors.white70)),
                    const SizedBox(height: 5),
                    Text("+৳${expectedReturn.toStringAsFixed(3)}",
                        style: const TextStyle(
                            color: Colors.green,
                            fontSize: 18,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text("Cycle Progress",
                      style: TextStyle(color: Colors.white)),
                  Text("${(progress * 100).toInt()}%",
                      style: const TextStyle(color: Colors.white)),
                ],
              ),
              LinearProgressIndicator(
                value: progress,
                color: Colors.white,
                backgroundColor: Colors.white24,
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: onWin,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20))),
                      child: const Text("WIN"),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: onLoss,
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20))),
                      child: const Text("LOSS"),
                    ),
                  ),
                  IconButton(
                    onPressed: reset,
                    icon: const Icon(Icons.refresh, color: Colors.white),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
